using Microsoft.EntityFrameworkCore;
using Pharmacy_DAO;

namespace PharmacyWebAPI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddDbContext<PharmacyDbContext>(options => options.UseSqlServer("Server=WKSPUN05GTR1008;Database=PharmacyDB;Integrated Security=True;Encrypt=False;TrustServerCertificate=False"));
            builder.Services.AddControllers();
            builder.Services.AddSwaggerGen();
            


            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}
