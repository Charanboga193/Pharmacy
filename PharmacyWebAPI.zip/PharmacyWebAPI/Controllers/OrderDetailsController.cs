﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Pharmacy_DAO;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PharmacyWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderDetailsController : ControllerBase
    {
        private readonly PharmacyDbContext _context;

        public OrderDetailsController(PharmacyDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IEnumerable<OrderDetail> Get()
        {
            return _context.OrderDetails.ToList();
        }


        [HttpGet("{id}")]
        public OrderDetail GetOrderDetail(int id)
        {
            var orderdetail = _context.OrderDetails.Find(id);

            if (orderdetail == null)
            {
                return new OrderDetail();
            }

            return orderdetail;
        }


        [HttpPost]
        public void PostOrderDetail([FromBody] OrderDetail orderdetail)
        {
            _context.OrderDetails.Add(orderdetail);
            _context.SaveChanges();
        }


        [HttpPut("{id}")]
        public void PutOrderDetail(int id, [FromBody] OrderDetail orderdetail)
        {
            _context.Entry(orderdetail).State = EntityState.Modified;
            _context.SaveChanges();
        }



        [HttpDelete("{id}")]
        public bool DeleteOrderDetail(int id)
        {
            var orderdetail = _context.OrderDetails.Find(id);
            if (orderdetail == null)
            {
                return false;
            }

            _context.OrderDetails.Remove(orderdetail);
            _context.SaveChanges();
            return true;

        }
    }
}
