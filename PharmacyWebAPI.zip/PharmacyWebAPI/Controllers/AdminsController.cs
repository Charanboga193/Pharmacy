﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Pharmacy_DAO;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PharmacyWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminsController : ControllerBase
    {
        private readonly PharmacyDbContext _context;

        public AdminsController(PharmacyDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IEnumerable<Admin> Get()
        {
            return _context.Admins.ToList();
        }


        [HttpGet("{id}")]
        public Admin GetAdmin(int id)
        {
            var admin = _context.Admins.Find(id);

            if (admin == null)
            {
                return new Admin();
            }

            return admin;
        }


        [HttpPost]
        public void PostAdmin([FromBody] Admin admin)
        {
            _context.Admins.Add(admin);
            _context.SaveChanges();
        }


        [HttpPut("{id}")]
        public void PutAdmin(int id, [FromBody] Admin admin)
        {
            _context.Entry(admin).State = EntityState.Modified;
            _context.SaveChanges();
        }



        [HttpDelete("{id}")]
        public bool DeleteAdmin(int id)
        {
            var admin = _context.Admins.Find(id);
            if (admin == null)
            {
                return false;
            }

            _context.Admins.Remove(admin);
            _context.SaveChanges();
            return true;

        }
    }
}
