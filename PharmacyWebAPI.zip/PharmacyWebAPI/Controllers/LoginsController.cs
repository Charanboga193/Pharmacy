﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Pharmacy_DAO;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PharmacyWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginsController : ControllerBase
    {
        // GET: api/<Logins>
        private readonly PharmacyDbContext _context;

        public LoginsController(PharmacyDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IEnumerable<Login> Get()
        {
            return _context.Logins.ToList();
        }


        [HttpGet("{id:int}")]
        public Login GetLogin(int id)
        {
            var login = _context.Logins.Find(id);

            if (login == null)
            {
                return new Login();
            }

            return login;
        }

        [HttpGet("{username}/{password}")]
        public string CheckLogin(string username, string password)
        {
            var login = _context.Logins.FirstOrDefault(m => (m.UserName == username && m.Password == password));

            if (login.LoginType == null)
            {
                return "";
            }

            return login.LoginType;
        }

        [HttpGet("{username}")]
        public string ForgotPwd(string username)
        {
            var login = _context.Logins.FirstOrDefault(m => (m.UserName == username));

            if (login.Password == null)
            {
                return "";
            }

            return login.Password;
        }


        [HttpPost]
        public void PostLogin([FromBody] Login login)
        {
            _context.Logins.Add(login);
            _context.SaveChanges();
        }


        [HttpPut("{id}")]
        public void PutLogin(int id, [FromBody] Login login)
        {
            _context.Entry(login).State = EntityState.Modified;
            _context.SaveChanges();
        }



        [HttpDelete("{id}")]
        public bool DeleteLogin(int id)
        {
            var login = _context.Logins.Find(id);
            if (login == null)
            {
                return false;
            }

            _context.Logins.Remove(login);
            _context.SaveChanges();
            return true;

        }
    }
}
