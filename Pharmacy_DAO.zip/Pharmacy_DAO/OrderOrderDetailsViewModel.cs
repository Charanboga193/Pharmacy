﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pharmacy_DAO
{
    public class OrderOrderDetailsViewModel
    {
        public Order Order { get; set; }
        public OrderDetail OrderDetail { get; set; }
    }
}
